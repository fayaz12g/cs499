module.exports = [
"[project]/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/app/favicon--route-entry.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAMAOAADADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACul/wA0Lb/BVNG82cwJ/CgKSHwhS8n8XRHPPVIUUT0IaGQ+gQAAOEA////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoYv6ALif+xJdT/WPQTXr8i8gxP8cDbb/KhzH/yof2PQ2LOreNy3xqVFE9W5kVfQk////AfLY/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFJF8wB8avYRXlD2kjww4vsyH7H/GASI/xgDiP8lE6z/JRSy/yYTqP8pGsT/MybZ/Eg78NlSRfVxemj2F2xb9AAAAAAAAAAAAAAAAAAAAAAAAAAAAJWA+gDrzP8BZFT1Mj4z83QpIO+KJBztiiYe7os4LvJ+MynyYk1B9zczLPcfYFL2XUM38LdBNOL7KRal/xUAhf8gDJf/MiLE/zcr5P8uHLf/FQGH/xUAh/8fCpL/Lx22/zks3P0+M/G9PTLwRwAAywCbhfoAAAAAAMGn/AAAAOgAemj3N0I38ppCNu7hNijT/yQUt/8aCq7/Hw+z/yETv/8mGcv/KB3b7CIX2eIwJN74LyXp/zIl2P8hErr/JBXA/zcq3f8+MNn/JxWn/xcDiv8VAIj/FQCI/xQAiP8UAIb/JhGZ/zcnyv84Lu66V0r1CUs/8QCWgPkA/+z/AlRG818/NO/ZNSbO/ykXqP8eCY//FQCG/xQAhf8VAIb/FQCH/xcCi/8XApD/FgKQ/xkFkv8iEKX/IRG0/xwNtv8fELT/JRSo/x0Jiv8UAIH/FACG/xYBif8XAov/FQCI/xUAiP8UAIb/HAmc/yQa5MMjHPgKIxvtADwy8ABBNvFGPDHs7TEhvv8cB47/FACG/xUAh/8VAIf/Kxin/yAOpv8VAIf/FQCI/xUAif8VAIn/FACE/xIAc/8PAGH/DgBa/w8AY/8SAHP/EgB0/xIAdf8TAIL/Gwmc/yESu/8VAIn/FQCI/xUAh/8XBZr/IhnjwyMe+QoiG+0AAADoADQr8mknGcv/GQSL/xQAh/8VAIj/FACH/yAMk/9AMtz/JhWz/xQAhv8VAIj/EQBt/xEAaf8QAGj/EABk/xMAe/8UAIT/FQCG/xUAiP8VAIj/FACH/yALj/8zI8b/JRjO/xYBif8VAIj/FgGH/ysZr/80KevDSz72CkI28AC9pP8DQTbxpyUVuv8VAIf/FQCI/xUAh/8eCI7/QS/H/zUo3f8hDZf/FACH/xUAh/8SAHL/EwB8/xUAh/8VAIn/FQCF/xIAcv8UAIP/FQCJ/xUAiP8VAYf/OCa7/zkt4/8iEar/FQCI/xQAh/8dCY//PjDa/kxA9Ib///8CkXz5ACMd/AQjGuiwGgmj/xUAhv8ZBIz/Jha2/ywf0P87L+P/JhSp/xUAh/8VAIj/FQCI/xUAif8VAIj/FQCI/xUAiP8VAIf/EQBu/w8AYv8RAGv/HQiN/zQit/89MeX/MB2z/xUAh/8VAIj/FQCH/yQQoP8sIeTgPDL0JDUr7wAAAAAAKSP3BCgf6rAnFa3/FQCJ/xgDjf8jEqv/HQ2w/yANnv8WAYj/FQCI/xUAiP8VAIj/FgGI/zAdrf8lE6v/FACH/xQAhf8QAGX/EQJk/ycbl/8tINH/OCzh/y8dtv8ZBIr/FQCI/xQAiP8cCI3/Py/S/Tov8KReT/QMVEbyAAAAAAD/9v8BRDnxjTMo4v8fE87/JxrQ/zIeq/8VAIX/FQCH/xUAiP8VAIj/FQCI/xQAh/8mEZj/RTfi/zwqwv8pE5X/FwOJ/xQAhP8WAYf/VEHP/2dT3f9GMbT/GgWQ/xUAif8VAIj/FwKJ/zontf82LOrnOS/yKhQN7QD/3/8AAAAAAGJT9ABkVfQbNizxXiMc8V81LPSdLR7H/RYBiP8VAIj/FQCI/xUAiP8VAIj/GAOK/zkpxf97aff/r5bq/4RvvP8xG5v/EwCH/xcCiv+SeNv/rpfY/35rv/83KNH/FwOP/xUAh/8YA43/LyLW9zgu8oJvXvQKYFHzAAAAAAAAAAAAAAAAAAAAAAAAAAAARjrxAEs/9zAuItnsGgWR/xUAh/8VAIj/FQCI/xQAhv8oFKD/PTHk/5+I8//Fq/j/r5fh/044rP8RAHz/FwKI/4520/++per/k3/l/zkr1v8YA4z/FQCH/xUBi/8iFtTxNSz1PCoh7gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOQfEATkH0GS8l69cqGLH/FQGI/xYBif8VAIb/Kxac/0U33P80Jcv/X0e6/4Nq0f9kTbz/Ggxk/xAAbv8UAIb/VUKW/6uU2/98avn/Lh23/xUAh/8WAon/IxCh/zEk1v82LPGR////AIRx9wAAAAAAAAAAAAAAAAAAAAAAAAAAAF9Q9ACiivoDOC7ygTIm2v81JL3/JxnG/ycXt/8/Md3/NCbU/xwIk/8VAYf/GAOK/xIBcv8PAGT/FQCH/xUAiP8WA3z/OCuB/zUqtv8kEZn/FACG/ysYqP80KN//NSTC/zcs6tU8MvEZQTfwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGBR8wBkVPQfQTbvuz807v4sJO//KB7f/yweyf8lEqL/FwOO/xUBif8UAID/DwBl/xQAhf8VAIj/FACH/ykWof88MNr/IBSC/w8AZP8cB4//Pi/W/ywcwf8gDZj/Jhvd4SIb9R4jG+0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAg3D3AEE18QBeT/QdPTLwaDgu744yJ+nBJx7j0iog4vUpHtr9LBin/xUAhf8UAIH/FQCI/xQAh/8dCY//PC3T/zUm0f8bBo7/EwCB/yIOmv82J87/HwuX/ywar/8vJereOS/yHTow8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACzm/oAvqT7A09D+AlEOfUZMSjyOz8086FCM9r/IAuT/xYBiP8WAIb/KRWd/z8w1P86Lt7/IQ2Z/xUAh/8VAIj/FgGJ/xsGjf8oFKH/PjDj90E28YiSffgGeGf2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPbU/wBJPPEAVEbzJDUr7NQrH9X8LR2+/yEStf87Lt//OizU/yUSnf8WAYj/FQCI/xQAh/8ZBIr/MyC1/zcs5PRLP/GcdWT2ClZI8wD/3/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIt3+ACii/oDTUHzKzMq8YIrIu/pMijt/zgnxv8eCpL/FACF/xUAh/8VAIf/HAeQ/zcmv/85LuntPzXyX56J+g4yKe8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuJe0AXE/zB1RG8j9CNu+/LSLh8ygby/8mFbD/GAag/yUSqf8+MNb/QTXv3VpM9V1nV/MEXE7zAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC1nPwA////AG5d9hA/NfNBOzHyhy0j7LIiGeexJx7pskI28ZhlVvQs////AeDE/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIBv9QC4oPkCPDP3BCUf/QQlH/kEhHH2A////wD31f8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA////////////////////////gH///wAP//4AB/AAAAPgAAABgAAAAYAAAAGAAAABAAAAAQAAAAMAAAADAAAAB4AAAAfwAAAP8AAAD/AAAAf4AAAH/AAAB/8AAAf/8AAP//AAH//8AD///wB////B//////////////////////8=", 'base64');
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__147c551c._.js.map