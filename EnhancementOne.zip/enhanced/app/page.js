"use client";
import React, { useState, useEffect, useRef } from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

const SpiralGame = () => {
  // Game state (React hooks instead of variables from Python class)
  const [currentRoom, setCurrentRoom] = useState('Portal');
  const [playerItems, setPlayerItems] = useState([]);
  const [moveCounter, setMoveCounter] = useState(1);
  const [gameText, setGameText] = useState('');
  const [gameStarted, setGameStarted] = useState(false);
  const [bossStage, setBossStage] = useState(0);
  const [bossMode, setBossMode] = useState(false);
  const [notEnoughItems, setNotEnoughItems] = useState(false);

  // Audio music components
  const backgroundMusicRef = useRef(null);
  const battleMusicRef = useRef(null);

   // Function to play sound effects
  const playSound = (soundFile) => {
    const audio = new Audio(`/sounds/${soundFile}`); // uses the passed in file name at the default sounds directory
    audio.volume = 0.5;
    audio.play().catch(e => console.log('Audio play failed:', e));
  };

  // Play background music on a loop
  const playMusic = (musicRef) => {
    // kill any existing background music if new one is called
    if (backgroundMusicRef.current) {
      backgroundMusicRef.current.pause();
    }
    // kill any existing battle music if new one is called
    if (battleMusicRef.current) {
      battleMusicRef.current.pause();
      battleMusicRef.current.currentTime = 0; // reset the battle music everytime
    }

    // start playing the new music
    if (musicRef.current) {
      musicRef.current.loop = true;
      musicRef.current.volume = 0.3;
      musicRef.current.play();
    }
  };

  // Room map (same as before)
  const rooms = {
    'Portal': { 'Down': 'Playroom', 'Up': 'Study', 'Left': 'Prayer Room', 'Right': 'Armory', 'Item': 'None' },
    'Study': { 'Down': 'Portal', 'Right': 'Family Room', 'Item': 'Logical Reasoning' },
    'Prayer Room': { 'Right': 'Portal', 'Item': 'Hope' },
    'Family Room': { 'Left': 'Study', 'Item': 'Reassurance' },
    'Nursery': { 'Down': 'Armory', 'Item': 'Guidance' },
    'Armory': { 'Up': 'Nursery', 'Left': 'Portal', 'Item': 'Mental Toughness' },
    'Playroom': { 'Right': 'Brain', 'Up': 'Portal', 'Item': 'Fun' },
    'Brain': { 'Left': 'Playroom', 'Item': 'None' }
  };

  // Map of new room images
  const roomImages = {
    'Portal': '/images/Portal.png',
    'Study': '/images/Study.png',
    'Prayer Room': '/images/Prayer Room.png',
    'Family Room': '/images/Family Room.png',
    'Nursery': '/images/Nursery.png',
    'Armory': '/images/Armory.png',
    'Playroom': '/images/Playroom.png',
    'Brain': '/images/Brain.png'
  };

  // Map of new item images
  const itemImages = {
    'Logical Reasoning': '/images/Logical Reasoning.png',
    'Hope': '/images/Hope.png',
    'Reassurance': '/images/Reassurance.png',
    'Guidance': '/images/Guidance.png',
    'Mental Toughness': '/images/Mental Toughness.png',
    'Fun': '/images/Fun.png'
  };

  // Boss battle correct items (same as before)
  const correctItems = {
    1: 'Logical Reasoning',
    2: 'Fun',
    3: 'Hope',
    4: 'Mental Toughness',
    5: 'Reassurance',
    6: 'Guidance'
  };

  // Function to get current room's item
  const getCurrentItem = () => rooms[currentRoom]['Item'];

  // Function to show current status (called on room change)
  const showStatus = () => {
    let text = "";
    
    // find if the room has an item
    const currentItem = getCurrentItem();
    if (currentItem !== "None") {
      // check if player already has the item
      if (playerItems.includes(currentItem)) {
        text += `This room contained ${currentItem}, but you've already collected it.\n`;
      } else {
        text += `This room contains ${currentItem}. You can collect it by tapping the collect button.\n`;
      }
    }
    
    // if there is no item, show default dialogue
    if (text === "") {
      text += "Select a direction to walk in using the DPAD.\n";
    }

    // set game text to what we created
    setGameText(text);

    // increment move counter
    setMoveCounter(prev => prev + 1);
  };

  // Function to move rooms
  const moveRooms = (direction) => {
    // don't allow movement in boss mode (besides flee)
    if (bossMode) return;
    
    // since button was pressed, play sound effect
    playSound('press.mp3');

    // check if the direction is valid
    if (direction in rooms[currentRoom]) {
      setCurrentRoom(rooms[currentRoom][direction]);
    } else {
      // Error handling (Should not be possible, but pulled from Python version)
      setGameText(`That is not a valid direction. Please try again!\nYou can move ${Object.keys(rooms[currentRoom]).filter(dir => dir !== 'Item').join(', ')}.`);
    }
  };

  // Function to collect item
  const collectItem = () => {
    // edge case (no collecting in boss mode)
    if (bossMode) return;
    
    // since button was pressed, play sound effect
    playSound('press.mp3');
    
    // get current item in the room
    const currentItem = getCurrentItem();
    setNotEnoughItems(false); // reset this flag when collecting items
    
    // if there is an item, and player doesn't already have it, add to inventory
    if (currentItem !== "None") {
      if (!playerItems.includes(currentItem)) {
        setPlayerItems(prev => [...prev, currentItem]);
        setGameText(`You have picked up ${currentItem}!`);
      } else {
        setGameText(`You already have ${currentItem} from this room!`);
      }
    } else {
      setGameText("There is nothing to pick up in this room!");
    }
  };

  // Function to start boss battle
  const startBossBattle = () => {
    // since button was pressed, play sound effect
    playSound('press.mp3');
    
    // check if player has all items
    const allItems = ['Logical Reasoning', 'Fun', 'Hope', 'Mental Toughness', 'Reassurance', 'Guidance'];
    const hasAllItems = allItems.every(item => playerItems.includes(item));
    
    // display warning if not all items are collected
    if (!hasAllItems) {
      setGameText("WARNING: You don't have all items! Go back and collect them before battling The Brain.");
      setNotEnoughItems(true);
      return;
    }
    
    // otherwise, start the boss battle
    setBossMode(true);
    setBossStage(1);
    showBossStage(1);
  };

  // Function to display boss stage text
  const showBossStage = (stage, attackResult) => {
    // default text is empty
    let text = "";

    // if attackResult is correct, show success or failure message
    if (attackResult === 1) {
      text += "Success! Your attack lands!\n";
    } else if (attackResult === 0) {
      text += "Oh no! That attack didn't land.\n\n";
    }
    
    const attacks = {
      1: "The boss has used the ANXIETY attack! Your thoughts are racing and you feel unsure!",
      2: "BOREDOM strikes! The brain is making you feel like there's nothing to do!",
      3: "DEPRESSION has hit, and you feel down as ever. What can you use to feel well again?",
      4: "OUCH! You have been hit with PAIN and ANGUISH. That one hurts.",
      5: "Suddenly, you are feeling SELF-DOUBT. You don't feel confident in anything.",
      6: "What is going on? You are so unsure. What can you use to combat this CONFUSION?",
      7: `Congratulations!! You have defeated all 6 stages and won the game in ${moveCounter} moves! Now try to defeat it again with fewer moves!`
    };
    
    // add the attack text for the current stage
    text += attacks[stage] + '\n\n';
    
    // if game is finished
    if (stage > 6) {
      setMoveCounter(0); // reset move counter for new game
    }
    
    // set the game text to what we created
    setGameText(text);
  };

  // Function to use an item in boss battle
  const useItem = (item) => {
    // edge case (only allow item use in boss mode)
    if (!bossMode || bossStage > 6) return;
    
    // since button was pressed, play sound effect
    playSound('press.mp3');
    
    // check if player has the item (should be impossible, but pulled from Python version)
    if (!playerItems.includes(item)) {
      setGameText("You don't have that item!");
      return;
    }
    
    // use the item and remove it from inventory
    setPlayerItems(prev => prev.filter(i => i !== item));
    setMoveCounter(prev => prev + 1);
    
    // check if the item is correct for the current boss stage
    if (item === correctItems[bossStage]) {
      setBossStage(prev => prev + 1);
      if (bossStage + 1 > 6) {
        showBossStage(7);
        setBossMode(false);
        stopBattleMusic();
      } else {
        showBossStage(bossStage + 1, 1);
      }
    } else {
      showBossStage(bossStage, 0);
    }
  };

  // Function to flee from battle and reset (keep inventory)
  const fleeBattle = () => {
    playSound('press.mp3');
    setBossMode(false);
    setBossStage(0);
    setCurrentRoom('Portal');
    stopBattleMusic();
  };

  // Initialize game
  useEffect(() => {
    if (!gameStarted) {
      setGameText("Welcome to Spiral!\n\nA text-based mental health adventure. Collect items to defeat your own mind.\n\nTap START to begin your journey...");
    }
  }, [gameStarted]);

  // Update status when room changes
  useEffect(() => {
    if (gameStarted && !bossMode) {
      if (currentRoom === 'Brain') {
        playMusic(battleMusicRef);
        setGameText("You have reached The Brain, the final boss of this game.\n\nPress the BATTLE button to begin the final confrontation!");
      } else {
           if (battleMusicRef.current) {
              playMusic(backgroundMusicRef);
            }
        showStatus();
      }
    }
  }, [currentRoom, gameStarted]);

  // Start game function
  const startGame = () => {
    playSound('press.mp3');
    setGameStarted(true);
    playMusic(backgroundMusicRef);
    setMoveCounter(0);
    showStatus();
  };

  // check if the direction is valid for movement
  const canMove = (direction) => {
    return !bossMode && gameStarted && direction in rooms[currentRoom];
  };

  return (
    // Tailwind CSS for styling
    <div className="min-h-screen bg-gradient-to-br from-pink-800 via-pink-900 to-pink-600 flex flex-col items-center justify-center p-4">
      {/* Audio elements */}
      <audio ref={backgroundMusicRef} preload="auto">
        <source src="/sounds/background.mp3" type="audio/mpeg" />
      </audio>
      <audio ref={battleMusicRef} preload="auto">
        <source src="/sounds/battle.mp3" type="audio/mpeg" />
      </audio>

      {/* Vertical console like screen div */}
      <div className="bg-slate-700 rounded-3xl p-6 shadow-2xl border-4 border-slate-600 max-w-sm w-full mb-4">
        {/* Top Part - Room Name and Move Counter */}
        <div className="text-center mb-4">
          {/* If Boss mode is active, display those stats */}
          {bossMode && bossStage <= 6 ? (
            <>
              <h1 className="text-red-500 font-bold text-2xl tracking-wider">THE BRAIN</h1>
              <h1 className="text-yellow-400 font-bold text-xl tracking-wider">BOSS STAGE {bossStage}</h1>
            </>
          ) : (
            // Otherwise, display normal stats
            <>
              <h1 className="text-blue-400 font-bold text-2xl tracking-wider">{currentRoom.toUpperCase()}</h1>
              <h1 className="text-yellow-400 font-bold text-xl tracking-wider">MOVE {moveCounter - 1}</h1>
            </>
          )}
        </div>

        {/* Screen with room image */}
        <div className="bg-green-900 border-4 border-gray-800 rounded-xl p-4 mb-6 aspect-square relative overflow-hidden">
          <img 
            src={roomImages[currentRoom]} // grab correct source from map
            alt={currentRoom} // alt text with room name
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>

        {/* Text Display (old console) */}
        <div className="bg-slate-200 border-2 border-slate-400 rounded p-4 mb-4 h-40 overflow-y-auto">
          <pre className="text-slate-800 text-xl font-sans whitespace-pre-wrap">{gameText}</pre>
        </div>

        {/* Controls */}
        {!gameStarted ? (
          <div className="text-center">
            <button
              onClick={startGame}
              className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg"
            >
              START
            </button>
          </div>
        ) : bossMode && bossStage <= 6 ? (
          /* Boss Battle Controls */
          <div className="space-y-3">
            <button
              onClick={fleeBattle}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded"
            >
              FLEE
            </button>
            <div className="text-center font-sans text-yellow-400 text-xl">Click items in inventory to attack!</div>
          </div>
        ) : (
          /* Normal Game Controls */
          <div className="space-y-4">
            
            {/* Action Buttons */}
            <div className="flex gap-2">
              {currentRoom !== 'Brain' && (
              <button
                onClick={collectItem}
                disabled={getCurrentItem() === "None" || playerItems.includes(getCurrentItem())}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white py-2 px-4 rounded text-sm"
              >COLLECT</button>
              )}
              {currentRoom === 'Brain' && !notEnoughItems && (
                <button
                  onClick={startBossBattle}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded text-sm"
                >
                  BATTLE
                </button>
              )}
            </div>

         {/* Padding before D-Pad */}
        <br />
                <br />
            {/* D-Pad */}
            <div className="flex justify-center">
              <div className="relative">
                {/* Up */}
                <button
                  onClick={() => moveRooms('Up')}
                  disabled={!canMove('Up')}
                  className={`absolute -top-12 left-1/2 transform -translate-x-1/2 w-12 h-12 rounded ${
                    canMove('Up') 
                      ? 'bg-slate-600 hover:bg-slate-500 text-white' 
                      : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  } flex items-center justify-center`}
                >
                  <ChevronUp size={40} />
                </button>
                
                {/* Left */}
                <button
                  onClick={() => moveRooms('Left')}
                  disabled={!canMove('Left')}
                  className={`absolute top-0 -left-12 w-12 h-12 rounded ${
                    canMove('Left') 
                      ? 'bg-slate-600 hover:bg-slate-500 text-white' 
                      : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  } flex items-center justify-center`}
                >
                  <ChevronLeft size={40} />
                </button>
                
                {/* Center */}
                <div className="w-12 h-12 bg-slate-500 rounded flex items-center justify-center">
                  <div className="w-2 h-2 bg-slate-800 rounded-full"></div>
                </div>
                
                {/* Right */}
                <button
                  onClick={() => moveRooms('Right')}
                  disabled={!canMove('Right')}
                  className={`absolute top-0 -right-12 w-12 h-12 rounded ${
                    canMove('Right') 
                      ? 'bg-slate-600 hover:bg-slate-500 text-white' 
                      : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  } flex items-center justify-center`}
                >
                  <ChevronRight size={40} />
                </button>
                
                {/* Down */}
                <button
                  onClick={() => moveRooms('Down')}
                  disabled={!canMove('Down')}
                  className={`absolute -bottom-12 left-1/2 transform -translate-x-1/2 w-12 h-12 rounded ${
                    canMove('Down') 
                      ? 'bg-slate-600 hover:bg-slate-500 text-white' 
                      : 'bg-slate-800 text-slate-600 cursor-not-allowed'
                  } flex items-center justify-center`}
                >
                  <ChevronDown size={40} />
                </button>
              </div>
            </div>
          </div>
        )}
              {/* Padding afterwards */}
                <br />
                <br />

      </div>
      

      {/* Inventory like Minecraft */}
      <div className="bg-slate-600 border-2 border-slate-500 rounded-lg p-4 max-w-sm w-full">
        <div className="text-white text-sm font-bold mb-3 text-center">INVENTORY</div>
        <div className="grid grid-cols-6 gap-2 relative">
          {/* Create using player items with 6 slots */}
          {Array.from({ length: 6 }, (_, index) => {
            const item = playerItems[index];
            return (
              <div 
                key={index} 
                className="w-14 h-14 bg-slate-800 border-2 border-slate-700 rounded flex items-center justify-center cursor-pointer hover:bg-slate-700 hover:border-slate-600 transition-all duration-200 relative group"
                onClick={() => bossMode && item && useItem(item)}
              >
                {/* show item image for every item */}
                {item ? (
                  <>
                    <img 
                      src={itemImages[item]} 
                      alt={item} // alt text with item name
                      className="w-12 h-12 object-contain"
                    />
                    <div className="text-white text-xs text-center hidden">
                      {item.split(' ').map(word => word[0]).join('')}
                    </div>
                    {/* on hover tooltip showing item name*/}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10 border border-gray-700">
                      {item}
                    </div>
                  </>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SpiralGame;