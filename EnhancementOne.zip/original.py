# Created by Fayaz Shaikh
import random

# Create a class to handle inventory
class GameState:
    def __init__(self, current_room, player_items, current_item, move_counter):
        self.current_room = current_room
        self.player_items = player_items
        self.current_item = current_item
        self.move_counter = move_counter

# Define the map and items
rooms = {
    'Portal': {'Down': 'Playroom', 'Up': 'Study', 'Left': 'Prayer Room', 'Right': 'Armory', 'Item': 'None'},
    'Study': {'Down': 'Portal', 'Right': 'Family Room', 'Item': 'Logical Reasoning'},
    'Prayer Room': {'Right': 'Portal', 'Item': 'Hope'},
    'Family Room': {'Left': 'Study', 'Item': 'Reassurance'},
    'Nursery': {'Down': 'Armory', 'Item': 'Guidance'},
    'Armory': {'Up': 'Nursery', 'Left': 'Portal', 'Item': 'Mental Toughness'},
    'Playroom': {'Right': 'Brain', 'Up': 'Portal', 'Item': 'Fun'},
    'Brain': {'Left': 'Playroom', 'Item': 'None'}
}

def show_status(game_state):
    print(f"\n\n------------------------------------------MOVE {game_state.move_counter}-------------------------------------------")
    print(f"You are currently in The {game_state.current_room}.")
    if game_state.current_item != "None":
        if game_state.current_item in game_state.player_items:
            print(f"This room contained {game_state.current_item}, but you've already collected it.")
        else:
            print(f"This room contains {game_state.current_item}. You can collect it by typing 'Collect Item'")
    if not game_state.player_items:
        print("Your inventory is empty.")
    else:
        # Randomize the list of items because I wrote this logic for the boss battle and wanna use it here too
        random.shuffle(game_state.player_items)
        items = game_state.player_items
        
        # Convert the list to a string with commas and spaces and add and before last word (with oxford comma)
        inventory_str = ", ".join(items[:-1])
        if len(items) > 1:
            inventory_str += ", and " + items[-1]
        elif len(items) == 1:
            inventory_str = items[0]

        print(f"You currently have {inventory_str}.")
    directions = [direction for direction in rooms[game_state.current_room] if direction != 'Item']

    # Convert the list to a string with commas and spaces and add and before last word (with oxford comma)
    directions_str = ", ".join(directions[:-1])
    if len(directions) > 1:
        directions_str += ", or " + directions[-1]
    elif len(directions) == 1:
        directions_str = directions[0]

    print(f"Currently, you can move {directions_str}.")
    print("You can always type '?' for more explicit options.")
    print("-------------------------------------------------------------------------------------------\n")
    game_state.move_counter = game_state.move_counter + 1

# Move the player in a direction
def moveRooms(command, game_state):
    # Make it lowercase to match input
    direction = command.split()[1].lower().capitalize()
    if direction in rooms[game_state.current_room]:
        game_state.current_room = rooms[game_state.current_room][direction]
        game_state.current_item = rooms[game_state.current_room]['Item']
        show_status(game_state)

    # Let the player know if they cannot move that way.
    else:
        print("That is not a valid direction. Please try again!")
        directions = [direction for direction in rooms[game_state.current_room] if direction != 'Item']
        print(f"You can move {directions}.")
 

# Give a player the item for the current room if it exists.
def giveItem(game_state):
    current_item = rooms[game_state.current_room]['Item']

    # Only execute if there is an item in the room
    if current_item != "None":

        # Ensure it is not already in the inventory
        if current_item not in game_state.player_items:
            print(f"You have picked up {current_item}!")
            game_state.player_items.append(current_item)
            show_status(game_state)
        else:
            print(f"You already have {current_item} from this room!")
            directions = [direction for direction in rooms[game_state.current_room] if direction != 'Item']
            print(f"You can move {directions} by typing 'Move', followed by a direction, or exit.")
    else:
        print("There is nothing to pick up in this room!")
        directions = [direction for direction in rooms[game_state.current_room] if direction != 'Item']
        print(f"You can move {directions} by typing 'Move', followed by a direction, or exit.")

# Function to simulate a player attack
def finishGame(game_state):
    boss_stage = 0
    previous_attack = 3
    print("You have reached The Brain, the final boss of this game.")
    if all(item in game_state.player_items for item in ['Logical Reasoning', 'Fun', 'Hope', 'Mental Toughness', 'Reassurance', 'Guidance']):
        begin_battle = input("\nPress enter to begin the boss battle...")
        boss_stage = 1
        
    else:
        begin_battle = input("WARNING: If you do not finish the boss battle, you will have to revisit rooms to regain items you use. Would you like to continue (y/n)?\n")
        if begin_battle == "y" or begin_battle == "Y":
            boss_stage = 1
        else:
            print("Sending you back to the portal...\n")
            game_state.current_room = "Portal"
    while boss_stage > 0 and boss_stage < 8:
        print(f"\n\n-------------------------------------------------BOSS STAGE {boss_stage}--------------------------------------------------")
        if previous_attack == 1:
            print(f"Success! Your attack lands, and you have obliterated the attack with your {player_choice}")
        if previous_attack == 0:
            print(f"Oh no! That attack didn't seem you land. You have used your {player_choice}.")
        if boss_stage == 1:
            print("The boss has used the ANXIETY attack! Your thoughts are racing and you feel unsure!")
        elif boss_stage == 2:
            print("BOREDEM strikes! The brain is making you feel like there's nothing to do!")
        elif boss_stage == 3:
            print("DEPRESSION has hit, and you feel down as ever. What ever can you use to feel well again?")
        elif boss_stage == 4:
            print("OUCH! You have been hit with PAIN and ANGUISH. That one hurts.")
        elif boss_stage == 5:
            print("Suddently, you are feeling SELF-DOUBT with yourself. You don't feel confident in anything you are doing.")
        elif boss_stage == 6:
            print("What is going on? You are so unsure. Whatever could you use to combat this CONFUSION?")
        elif boss_stage == 7:
            print("Congratulations!! You have defeated all 6 stages of the boss fight, and won the game.")
            game_state.current_room = "exit"

        # Randomize the list of items so that if you use the get all cheat, they are not in attack order
        random.shuffle(game_state.player_items)
        
        # Get the list of items
        items = game_state.player_items

        # Convert the list to a string with commas and spaces
        inventory_str = ", ".join(items[:-1])

        # Add "and" before the last item
        if len(items) > 1:
            inventory_str += ", and " + items[-1]
        elif len(items) == 1:
            inventory_str = items[0]

        print(f"Your inventory contains {inventory_str}.")
        print(f"-----------------------------------------------------------------------------------------------------------------\n")
    
        player_choice = input("Enter the item you want to attack with, or type 'flee' to leave: ").strip().title()

        if player_choice == 'Exit':
            game_state.current_room = 'exit'
            boss_stage = 0
            print("\nExiting the game...")
            return

        elif player_choice == "Flee":
            print("You fled the battle. Returning to the Portal.\n")
            game_state.current_room = "Portal"
            show_status(game_state)
            return

        elif player_choice not in game_state.player_items:
            print("\nYou don't have that item!\n")

        # Check if the player used the correct item
        correct_items = {
            1: 'Logical Reasoning',
            2: 'Fun',
            3: 'Hope',
            4: 'Mental Toughness',
            5: 'Reassurance',
            6: 'Guidance'
        }

        if player_choice == correct_items[boss_stage]:
            game_state.player_items.remove(player_choice)
            boss_stage = boss_stage + 1
            previous_attack = 1
            game_state.move_counter = game_state.move_counter + 1
        
        elif player_choice in game_state.player_items:
            previous_attack = 0
            game_state.player_items.remove(player_choice)
            game_state.move_counter = game_state.move_counter + 1

# Start the gameplay loop, which ends if the user's current room is exit.
def main():
    # Set the starting room to the entrance and set the player items to an empty array, as well as a counter.
    game_state = GameState('Portal', [], 'None', 1)
    # Create a game start to do a show status (future show statuses are done in MoveRooms, as sense. wanted me to)
    game_start = 1
    while game_state.current_room != 'exit':
        if game_state.current_room == 'Brain':
            finishGame(game_state)
        else:
            current_item = rooms[game_state.current_room]['Item']
            if game_start == 1:
                print(f'''\nWelcome to a simple text based game created by Fayaz for IT-140 at SNHU! Defeat the brain before you die!
\nThis game, Spiral, delves into mental health as you as the protagonist must face your own mind after collecting everything you need to defeat it. You begin by entering your head through the portal.''')
                start_game = input("\nPress enter to begin...")
                show_status(game_state)
                game_start = 0

            # Remove case sensitivity from the input.
            command = input('What would you like to do?\n').strip().lower()

            # Stop the game if the user exits by ending the while loop
            if command == 'exit':
                game_state.current_room = 'exit'
                print("\nI hope you had fun!\n\nNow exiting...")

            # Call moveRooms function
            elif command.startswith('move'):
                moveRooms(command, game_state)

            # Call giveItem function
            elif command.startswith('collect item'):
                giveItem(game_state)

            # Give All Items
            elif command.startswith('sv_cheats = 1'):
                game_state.player_items = ['Logical Reasoning', 'Fun', 'Mental Toughness', 'Hope', 'Reassurance', 'Guidance']
                print("\nYou have succesfully cheated, Mr. Cheater!\n")
                show_status(game_state)
            
            # Teleport to End
            elif command.startswith('noclip'):
                game_state.current_room = "Brain"
                print("\nYou have teleported to the end\n")

            # Teleport to End
            elif command.startswith('?'):
                print(f'''\n--------------------------------MOVEMENT-----------------------------------
If you would like to move rooms, please enter the word "Move", followed by a direction.
For example, you can enter "Move Up", "Move Down", "Move Left", or "Move Right".
\n----------------------------------INVENTORY-------------------------------------
To pick up an item, if you are in a room with a valid item, simply type "Collect Item".
Items can be removed from your inventory when used during the boss fight.
Items can only be collected from a room once, unless used during a boss fight.
\n-----------------------------------CHEATS--------------------------------------
To collect all items, enter "sv_cheats = 1".
To teleport to the boss fight, enter "noclip".
\n----------------------------------EXIT-------------------------------------
To quit the game, simply type "exit".
\n''')

            # Remind the player valid moves if they do not say one
            else:
                print('\nInvalid command. Enter "?" for a list of all possible commands.\n')

# Start the game
main()