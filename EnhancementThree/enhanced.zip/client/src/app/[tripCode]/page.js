"use client";
import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import Header from "../components/header";
import Background from "../components/background";
import Footer from "../components/footer";
import { tripsService } from "../services/tripsService";
import { userService } from "../services/userService";
import { Calendar, MapPin, DollarSign, Clock, Star, Edit2, Save, X, Trash2, ArrowLeft } from "lucide-react";

export default function TripDetail() {
  const router = useRouter();
  const params = useParams();
  const tripCode = params?.tripCode;

  const [trip, setTrip] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [isBooked, setIsBooked] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);

  const [editData, setEditData] = useState({
    title: "",
    destination: "",
    image: "",
    description: "",
    startDateTime: "",
    rating: 3,
    price: "",
    length: ""
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (tripCode) {
      loadTrip();
      checkAdminStatus();
      checkIfBooked();
    }
  }, [tripCode]);

  const loadTrip = async () => {
    try {
      setLoading(true);
      const res = await tripsService.getTrip(tripCode);
      if (res.ok) {
        const data = await res.json();
        setTrip(data);
        setEditData({
          title: data.title,
          destination: data.destination,
          image: data.image,
          description: data.description,
          startDateTime: data.startDateTime,
          rating: data.rating,
          price: data.price,
          length: data.length
        });
      } else {
        alert("Trip not found");
        router.push('/browse');
      }
    } catch (err) {
      console.error("Error loading trip:", err);
      alert("Failed to load trip");
      router.push('/browse');
    } finally {
      setLoading(false);
    }
  };

  const checkAdminStatus = async () => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const res = await userService.userAdminStatus();
        if (res.ok) {
          const data = await res.json();
          setIsAdmin(data.admin);
        }
      } catch (err) {
        console.error("Error checking admin status:", err);
      }
    }
  };

  const checkIfBooked = async () => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const res = await tripsService.getUserTrips();
        if (res.ok) {
          const userTrips = await res.json();
          const booked = userTrips.some(t => t.code === tripCode);
          setIsBooked(booked);
        }
      } catch (err) {
        console.error("Error checking booking status:", err);
      }
    }
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ""
      }));
    }
  };

  const validateEdit = () => {
    const newErrors = {};
    if (!editData.title.trim()) newErrors.title = "Title is required";
    if (!editData.destination.trim()) newErrors.destination = "Destination is required";
    if (!editData.image.trim()) newErrors.image = "Image URL is required";
    if (!editData.description.trim()) newErrors.description = "Description is required";
    if (!editData.startDateTime) newErrors.startDateTime = "Start date is required";
    if (!editData.price || editData.price <= 0) newErrors.price = "Valid price is required";
    if (!editData.length.trim()) newErrors.length = "Length is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveEdit = async () => {
    if (!validateEdit()) return;

    setSaving(true);
    try {
      const res = await tripsService.editTrip(tripCode, {
        ...editData,
        destination: editData.destination,
        price: parseInt(editData.price),
        rating: parseInt(editData.rating)
      });

      if (res.ok) {
        alert("Trip updated successfully!");
        setIsEditing(false);
        await loadTrip();
      } else {
        const errorData = await res.json();
        alert(`Failed to update trip: ${errorData.error || 'Unknown error'}`);
      }
    } catch (err) {
      console.error("Error updating trip:", err);
      alert("Failed to update trip");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this trip? This action cannot be undone.")) {
      return;
    }

    try {
      const res = await tripsService.deleteTrip(tripCode);
      if (res.ok) {
        alert("Trip deleted successfully!");
        router.push('/browse');
      } else {
        const errorData = await res.json();
        alert(`Failed to delete trip: ${errorData.error || 'Unknown error'}`);
      }
    } catch (err) {
      console.error("Error deleting trip:", err);
      alert("Failed to delete trip");
    }
  };

  const handleBooking = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Please log in to book this trip");
      router.push('/login');
      return;
    }

    setBookingLoading(true);
    try {
      if (isBooked) {
        console.log("Unbooking trip...");
        const res = await tripsService.unbookTrip(tripCode);
        if (res.ok) {
          setIsBooked(false);
          alert("Trip unbooked successfully!");
        } else {
          const errorData = await res.json();
          alert(`Failed to unbook trip: ${errorData.error || 'Unknown error'}`);
        }
      } else {
        const res = await tripsService.bookTrip(tripCode);
        if (res.ok) {
          setIsBooked(true);
          alert("Trip booked successfully!");
        } else {
          const errorData = await res.json();
          alert(`Failed to book trip: ${errorData.error || 'Unknown error'}`);
        }
      }
    } catch (err) {
      console.error("Error toggling booking:", err);
      alert("Failed to process booking");
    } finally {
      setBookingLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderStars = (rating) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={24}
            className={i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
          />
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div>
        <Header />
        <Background />
        <div className="flex items-center justify-center min-h-screen">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
        </div>
      </div>
    );
  }

  if (!trip) {
    return null;
  }

  return (
    <div>
      <Header />
      <Background />
      <br />
      <main className="max-w-5xl mx-auto p-6 mt-24 relative z-10 mb-12">
        <button
          onClick={() => router.push('/browse')}
          className="flex items-center gap-2 mb-6 text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft size={20} />
          Back to Browse
        </button>

        <div className="bg-white/10 rounded-xl overflow-hidden backdrop-blur-sm shadow-2xl">
          {!isEditing ? (
            <>
              <div className="relative h-96 overflow-hidden">
                <img
                  src={trip.image}
                  alt={trip.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm px-4 py-2 rounded-full">
                  {renderStars(trip.rating)}
                </div>
              </div>

              <div className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex-1">
                    <h1 className="text-4xl font-bold mb-3">{trip.title}</h1>
                    <div className="flex items-center gap-2 text-gray-300 text-lg mb-4">
                      <MapPin size={20} />
                      <span>{trip.destination}</span>
                    </div>
                  </div>

                  {isAdmin && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => setIsEditing(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg transition-colors"
                      >
                        <Edit2 size={18} />
                        Edit
                      </button>
                      <button
                        onClick={handleDelete}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500 hover:bg-red-600 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                        Delete
                      </button>
                    </div>
                  )}
                </div>

                <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                  {trip.description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 p-6 bg-white/5 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Calendar size={24} className="text-blue-400" />
                    <div>
                      <p className="text-sm text-gray-400">Departure</p>
                      <p className="font-semibold">{formatDate(trip.startDateTime)}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Clock size={24} className="text-green-400" />
                    <div>
                      <p className="text-sm text-gray-400">Duration</p>
                      <p className="font-semibold">{trip.length}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <DollarSign size={24} className="text-yellow-400" />
                    <div>
                      <p className="text-sm text-gray-400">Price</p>
                      <p className="font-semibold text-2xl text-green-400">${trip.price}</p>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={handleBooking}
                  disabled={bookingLoading}
                  className={`w-full px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none ${
                    isBooked
                      ? 'bg-red-500 hover:bg-red-600'
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700'
                  }`}
                >
                  {bookingLoading ? 'Processing...' : isBooked ? 'Unbook Trip' : 'Book This Trip'}
                </button>

              </div>
            </>
          ) : (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold">Edit Trip</h2>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setEditData({
                      title: trip.title,
                      type: trip.type,
                      image: trip.image,
                      description: trip.description,
                      startDateTime: trip.startDateTime,
                      rating: trip.rating,
                      price: trip.price,
                      length: trip.length
                    });
                    setErrors({});
                  }}
                  className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X size={18} />
                  Cancel
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Title</label>
                  <input
                    type="text"
                    name="title"
                    value={editData.title}
                    onChange={handleEditChange}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                  />
                  {errors.title && <p className="text-red-400 text-sm mt-1">{errors.title}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Destination</label>
                  <input
                    type="text"
                    name="destination"
                    value={editData.destination}
                    onChange={handleEditChange}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                  />
                  {errors.destination && <p className="text-red-400 text-sm mt-1">{errors.destination}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Image URL</label>
                  <input
                    type="url"
                    name="image"
                    value={editData.image}
                    onChange={handleEditChange}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                  />
                  {errors.image && <p className="text-red-400 text-sm mt-1">{errors.image}</p>}
                  {editData.image && (
                    <img src={editData.image} alt="Preview" className="mt-3 w-full h-48 object-cover rounded-lg" onError={(e) => { e.target.style.display = 'none'; }} />
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Description</label>
                  <textarea
                    name="description"
                    value={editData.description}
                    onChange={handleEditChange}
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white resize-none"
                  />
                  {errors.description && <p className="text-red-400 text-sm mt-1">{errors.description}</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Start Date & Time</label>
                    <input
                      type="datetime-local"
                      name="startDateTime"
                      value={editData.startDateTime}
                      onChange={handleEditChange}
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                    />
                    {errors.startDateTime && <p className="text-red-400 text-sm mt-1">{errors.startDateTime}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Trip Length</label>
                    <input
                      type="text"
                      name="length"
                      value={editData.length}
                      onChange={handleEditChange}
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                    />
                    {errors.length && <p className="text-red-400 text-sm mt-1">{errors.length}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Price (USD)</label>
                    <input
                      type="number"
                      name="price"
                      value={editData.price}
                      onChange={handleEditChange}
                      min="0"
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
                    />
                    {errors.price && <p className="text-red-400 text-sm mt-1">{errors.price}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Rating (1-5)</label>
                    <div className="flex items-center gap-4">
                      <input
                        type="range"
                        name="rating"
                        value={editData.rating}
                        onChange={handleEditChange}
                        min="1"
                        max="5"
                        className="flex-1"
                      />
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={20}
                            className={i < editData.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSaveEdit}
                  disabled={saving}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 rounded-lg font-semibold transition-all transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <Save size={20} />
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}