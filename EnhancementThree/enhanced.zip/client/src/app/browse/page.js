"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Header from "../components/header";
import Background from "../components/background";
import Footer from "../components/footer";
import { tripsService } from "../services/tripsService";
import { userService } from "../services/userService";
import { Calendar, Star, MapPin, Plus } from "lucide-react";

export default function Browse() {
  const router = useRouter();
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    loadTrips();
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    // Check if user is logged in and is admin
    const token = localStorage.getItem("token");
    if (token) {
      try {
        const res = await userService.userAdminStatus();
        if (res.ok) {
          const data = await res.json();
          setIsAdmin(data.admin);
        }
      } catch (err) {
        console.error("Error checking admin status:", err);
      }
    }
  };

  const loadTrips = async () => {
    try {
      setLoading(true);
      const res = await tripsService.getTrips();
      if (!res.ok) {
        console.error("Failed to fetch trips");
        return;
      }
      const data = await res.json();
      setTrips(data);
    } catch (err) {
      console.error("Error loading trips:", err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const renderStars = (rating) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={14}
            className={i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
          />
        ))}
      </div>
    );
  };

  return (
    <div>
      <Header />
      <br />
      <Background />
      <main className="max-w-7xl mx-auto p-6 mt-24 relative z-10">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <h1 className="text-5xl font-bold">Browse Trips</h1>
            {isAdmin && (
              <button
                onClick={() => router.push('/create')}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 rounded-lg text-white font-semibold transition-all transform hover:scale-105 shadow-lg"
              >
                <Plus size={20} />
                Create Trip
              </button>
            )}
          </div>
          <p className="text-lg text-gray-300">
            Explore available trips and book your next adventure!
          </p>
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
            <p className="mt-4 text-gray-300">Loading trips...</p>
          </div>
        ) : trips.length === 0 ? (
          <p className="text-center text-gray-400 italic py-20">
            No trips available yet. Check back soon!
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trips.map((trip) => (
              <Link key={trip.code} href={`/${trip.code}`}>
                <div className="bg-white/10 rounded-xl overflow-hidden backdrop-blur-sm hover:bg-white/15 transition-all cursor-pointer transform hover:scale-105 shadow-lg hover:shadow-2xl">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={trip.image}
                      alt={trip.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full">
                      {renderStars(trip.rating)}
                    </div>
                  </div>
                  
                  <div className="p-5">
                    <h2 className="text-xl font-bold mb-2 line-clamp-1">{trip.title}</h2>
                    
                    <div className="flex items-center gap-2 text-gray-300 text-sm mb-2">
                      <MapPin size={16} />
                      <span className="line-clamp-1">{trip.destination}</span>
                    </div>
                    
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                      {trip.description || "No description provided."}
                    </p>
                    
                    <div className="flex items-center justify-between pt-3 border-t border-white/10">
                      <div className="flex items-center gap-2 text-sm text-gray-300">
                        <Calendar size={16} />
                        <span>{formatDate(trip.startDateTime)}</span>
                      </div>
                      <div className="text-lg font-bold text-green-400">
                        ${trip.price}
                      </div>
                    </div>
                    
                    <div className="mt-3 text-xs text-gray-400">
                      Duration: {trip.length}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}