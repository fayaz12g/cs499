"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Header from "../components/header";
import Background from "../components/background";
import Footer from "../components/footer";
import { tripsService } from "../services/tripsService";
import { userService } from "../services/userService";
import { Calendar, MapPin, DollarSign, Clock, Star, Image as ImgIcon, FileText } from "lucide-react";

export default function CreateTrip() {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    destination: "",
    image: "",
    description: "",
    startDateTime: "",
    rating: 3,
    price: "",
    length: ""
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      router.push('/browse');
      return;
    }

    try {
      const res = await userService.userAdminStatus();
      if (res.ok) {
        const data = await res.json();
        if (data.admin) {
          setIsAdmin(true);
        } else {
          alert("You don't have permission to create trips.");
          router.push('/browse');
        }
      } else {
        router.push('/browse');
      }
    } catch (err) {
      console.error("Error checking admin status:", err);
      router.push('/browse');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ""
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) newErrors.title = "Title is required";
    if (!formData.destination.trim()) newErrors.destination = "Destination is required";
    if (!formData.image.trim()) newErrors.image = "Image URL is required";
    if (!formData.description.trim()) newErrors.description = "Description is required";
    if (!formData.startDateTime) newErrors.startDateTime = "Start date is required";
    if (!formData.price || formData.price <= 0) newErrors.price = "Valid price is required";
    if (!formData.length.trim()) newErrors.length = "Trip length is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setSubmitting(true);
    try {
      const response = await tripsService.createTrip({
        ...formData,
        price: parseInt(formData.price),
        rating: parseInt(formData.rating)
      });

      if (response.ok) {
        const data = await response.json();
        alert("Trip created successfully!");
        router.push(`/${data.code}`);
      } else {
        const errorData = await response.json();
        alert(`Failed to create trip: ${errorData.error || 'Unknown error'}`);
      }
    } catch (err) {
      console.error("Error creating trip:", err);
      alert("Failed to create trip. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div>
        <Header />
        <Background />
        <div className="flex items-center justify-center min-h-screen">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div>
      <Header />
      <Background />
      <br />
      <main className="max-w-4xl mx-auto p-6 mt-24 relative z-10 mb-12">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-4">Create New Trip</h1>
          <p className="text-lg text-gray-300">
            Add a new adventure for travelers to discover
          </p>
        </div>

        <div className="bg-white/10 rounded-xl p-8 backdrop-blur-sm shadow-lg">
          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
              <FileText size={18} />
              Trip Title
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="e.g., Amazing Safari Adventure in Kenya"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400"
            />
            {errors.title && <p className="text-red-400 text-sm mt-1">{errors.title}</p>}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
              <MapPin size={18} />
              Destination
            </label>
            <input
              type="text"
              name="destination"
              value={formData.destination}
              onChange={handleChange}
              placeholder="e.g., Kenya, Africa or Beach Vacation"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400"
            />
            {errors.destination && <p className="text-red-400 text-sm mt-1">{errors.destination}</p>}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
              <ImgIcon size={18} />
              Image URL
            </label>
            <input
              type="url"
              name="image"
              value={formData.image}
              onChange={handleChange}
              placeholder="https://example.com/image.jpg"
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400"
            />
            {errors.image && <p className="text-red-400 text-sm mt-1">{errors.image}</p>}
            {formData.image && (
              <div className="mt-3 rounded-lg overflow-hidden">
                <img 
                  src={formData.image} 
                  alt="Preview" 
                  className="w-full h-48 object-cover" 
                  onError={(e) => { e.target.style.display = 'none'; }}
                />
              </div>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold mb-2">
              Description
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={4}
              placeholder="Describe the trip experience..."
              className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400 resize-none"
            />
            {errors.description && <p className="text-red-400 text-sm mt-1">{errors.description}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                <Calendar size={18} />
                Start Date & Time
              </label>
              <input
                type="datetime-local"
                name="startDateTime"
                value={formData.startDateTime}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white"
              />
              {errors.startDateTime && <p className="text-red-400 text-sm mt-1">{errors.startDateTime}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                <Clock size={18} />
                Trip Length
              </label>
              <input
                type="text"
                name="length"
                value={formData.length}
                onChange={handleChange}
                placeholder="e.g., 7 days, 2 weeks"
                className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400"
              />
              {errors.length && <p className="text-red-400 text-sm mt-1">{errors.length}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                <DollarSign size={18} />
                Price (USD)
              </label>
              <input
                type="number"
                name="price"
                value={formData.price}
                onChange={handleChange}
                min="0"
                placeholder="999"
                className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 focus:border-blue-500 focus:outline-none transition-colors text-white placeholder-gray-400"
              />
              {errors.price && <p className="text-red-400 text-sm mt-1">{errors.price}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                <Star size={18} />
                Rating (1-5)
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  name="rating"
                  value={formData.rating}
                  onChange={handleChange}
                  min="1"
                  max="5"
                  className="flex-1"
                />
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      className={i < formData.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              type="button"
              onClick={() => router.push('/browse')}
              className="flex-1 px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors font-semibold"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 rounded-lg text-white font-semibold transition-all transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {submitting ? "Creating..." : "Create Trip"}
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}