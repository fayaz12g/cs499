"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '../components/header';
import Background from '../components/background';
import Footer from '../components/footer';
import { tripsService } from '../services/tripsService';
import { Calendar, Star, MapPin } from 'lucide-react';

const HomePage = () => {
  const router = useRouter();
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchUserTrips();
  }, []);

  const fetchUserTrips = async () => {
    try {
      setLoading(true);
      const response = await tripsService.getUserTrips();
      
      if (response.ok) {
        const data = await response.json();
        setTrips(data);
      } else {
        setError('Failed to load your trips');
      }
    } catch (err) {
      console.error('Error fetching trips:', err);
      setError('Failed to load your trips');
    } finally {
      setLoading(false);
    }
  };

  const handleTripClick = (code) => {
    router.push(`/${code}`);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const renderStars = (rating) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={16}
            className={i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen">
      <Header />
      <Background />
      <br />

      <main className="max-w-7xl mx-auto p-6 mt-24 relative z-10">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">My Trips</h1>
          <p className="text-lg text-gray-300">
            Your booked adventures await
          </p>
        </div>

        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
            <p className="mt-4 text-gray-300">Loading your trips...</p>
          </div>
        ) : error ? (
          <div className="text-center py-20">
            <p className="text-red-400 mb-4">{error}</p>
            <button 
              onClick={fetchUserTrips}
              className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : trips.length === 0 ? (
          <div className="text-center py-20">
            <div className="bg-white/10 rounded-xl p-12 max-w-2xl mx-auto backdrop-blur-sm">
              <h2 className="text-3xl font-semibold mb-4">No trips booked yet</h2>
              <p className="text-gray-300 mb-8 text-lg">
                Start your adventure by booking your first trip!
              </p>
              <button
                onClick={() => router.push('/browse')}
                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 rounded-lg text-white font-semibold transition-all transform hover:scale-105 shadow-lg"
              >
                Browse Trips
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trips.map((trip) => (
              <div
                key={trip.id}
                onClick={() => handleTripClick(trip.code)}
                className="bg-white/10 rounded-xl overflow-hidden backdrop-blur-sm hover:bg-white/15 transition-all cursor-pointer transform hover:scale-105 shadow-lg hover:shadow-2xl"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={trip.image}
                    alt={trip.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full">
                    {renderStars(trip.rating)}
                  </div>
                </div>
                
                <div className="p-5">
                  <h3 className="text-xl font-bold mb-2 line-clamp-1">{trip.title}</h3>
                  
                  <div className="flex items-center gap-2 text-gray-300 text-sm mb-2">
                    <MapPin size={16} />
                    <span className="line-clamp-1">{trip.destination}</span>
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                    {trip.description}
                  </p>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <Calendar size={16} />
                      <span>{formatDate(trip.startDateTime)}</span>
                    </div>
                    <div className="text-lg font-bold text-green-400">
                      ${trip.price}
                    </div>
                  </div>
                  
                  <div className="mt-3 text-xs text-gray-400">
                    Duration: {trip.length}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;