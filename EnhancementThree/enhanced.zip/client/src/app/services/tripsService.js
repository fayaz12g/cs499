import { getServerPath } from '../utils/config';

export const tripsService = {

  // Get trip details by code
  async getTrip(code) {
    try {
      const response = await fetch(`${getServerPath()}/trips/${code}`, {
        method: 'GET',
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      });
      return response;
    } catch (error) {
      console.error('Error fetching trip:', error);
      throw error;
    }
  },

  // Get all trips
  async getTrips() {
    try {
      const response = await fetch(`${getServerPath()}/trips`, {
        method: 'GET',
        headers: {
          "Content-type": "application/json; charset=UTF-8",
        },
      });
      return response;
    } catch (error) {
      console.error('Error fetching trip:', error);
      throw error;
    }
  },


 // Create a new trip
  async createTrip(payload) {
    const res = await fetch(`${getServerPath()}/trips`, {
      method: "POST",
      body: JSON.stringify({
        title: payload.title,
        destination: payload.destination,
        image: payload.image,
        description: payload.description,
        startDateTime: payload.startDateTime,
        rating: payload.rating,
        price: payload.price,
        length: payload.length
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },


 // Edit a trip
  async editTrip(tripCode, payload) {
    const res = await fetch(`${getServerPath()}/trips/${tripCode}`, {
      method: "PUT",
      body: JSON.stringify({
        title: payload.title,
        destination: payload.destination,
        image: payload.image,
        description: payload.description,
        startDateTime: payload.startDateTime,
        rating: payload.rating,
        price: payload.price,
        length: payload.length
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },

  // Delete trip
  async deleteTrip(code) {
    const res = await fetch(`${getServerPath()}/trips/${code}`, {
      method: "DELETE",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },

  // Book trip
  async bookTrip(code) {
    const res = await fetch(`${getServerPath()}/trips/${code}/book`, {
      method: "POST",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },


  // Unbook trip
  async unbookTrip(code) {
    const res = await fetch(`${getServerPath()}/trips/${code}/book`, {
      method: "DELETE",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },
  
  // Delete trip
  async deleteTrip(code) {
    const res = await fetch(`${getServerPath()}/trips/${code}`, {
      method: "DELETE",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },

  // Get user's trips
  async getUserTrips() {
    const res = await fetch(`${getServerPath()}/moderate/trips`, {
      method: "GET",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        "Authorization": `Bearer ${localStorage.getItem("token")}`
      }
    });

    return Promise.resolve(res);
  },
};
