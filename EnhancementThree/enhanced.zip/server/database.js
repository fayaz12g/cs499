const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');

const DB_FILE = "./database.db";

// Sqlite 3 Database
let db;

// Initialize Database
const init = () => {
  console.log('Initializing Database...');

  // Connect to database file
  console.log("Connecting to database file " + DB_FILE);
  db = new sqlite3.Database(DB_FILE, (err) => {
    if (err) {
      console.error("Error opening database from file: ", err);
    } else {
      console.log("Connected to database file successfully");
    }
  });

  // Users table
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT,
      firstName TEXT,
      lastName TEXT,
      email TEXT,
      profileIcon TEXT,
      admin BOOLEAN DEFAULT 0
    )
  `, (err) => {
    if (err) {
      console.error("Error creating users table:", err);
    } else {
      console.log("Users table created or already exists");
    }
  });

  // Trips table
  db.run(`
    CREATE TABLE IF NOT EXISTS trips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      destination TEXT NOT NULL,
      image TEXT NOT NULL,
      description TEXT NOT NULL,
      startDateTime TEXT NOT NULL,
      rating INTEGER NOT NULL,
      price INTEGER NOT NULL,
      length TEXT NOT NULL
    )
  `, (err) => {
    if (err) {
      console.error("Error creating trips table:", err);
    } else {
      console.log("Trips table created or already exists");
    }
  });

  // User bookings (many-to-many)
  db.run(`
    CREATE TABLE IF NOT EXISTS user_trips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      trip_id INTEGER NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(trip_id) REFERENCES trips(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating user_trips table:", err);
    } else {
      console.log("User_trips table created or already exists");
    }
  });
};

 const addUser = (data) => new Promise((resolve, reject) => {
  const { username, password, firstName, lastName, email, profileIcon, admin = 0 } = data;
  db.run(
    `INSERT INTO users (username, password, firstName, lastName, email, profileIcon, admin)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [username, password, firstName, lastName, email, profileIcon, admin],
    function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, username });
    }
  );
});

 const updateUser = (data) => new Promise((resolve, reject) => {
  const { id, username, password, firstName, lastName, email, profileIcon } = data;
  db.run(
    `UPDATE users
     SET username=?, password=?, firstName=?, lastName=?, email=?, profileIcon=?
     WHERE id=?`,
    [username, password, firstName, lastName, email, profileIcon, id],
    function (err) {
      if (err) reject(err);
      else resolve({ changes: this.changes });
    }
  );
});

 const getUser = (id) => new Promise((resolve, reject) => {
  db.get('SELECT * FROM users WHERE id=?', [id], (err, user) => {
    if (err) reject(err);
    else resolve(user);
  });
});

 const getUserByUsername = (username) => new Promise((resolve, reject) => {
  db.get('SELECT * FROM users WHERE username=?', [username], (err, user) => {
    if (err) reject(err);
    else resolve(user);
  });
});

 const getAllUsers = () => new Promise((resolve, reject) => {
  db.all('SELECT * FROM users', (err, users) => {
    if (err) reject(err);
    else resolve(users);
  });
});

 const getAllTrips = () => new Promise((resolve, reject) => {
  db.all('SELECT * FROM trips', (err, trips) => {
    if (err) reject(err);
    else resolve(trips);
  });
});

 const getTripByCode = (code) => new Promise((resolve, reject) => {
  db.get('SELECT * FROM trips WHERE code=?', [code], (err, trip) => {
    if (err) reject(err);
    else resolve(trip);
  });
});

const isTrippedBooked = (userId, tripId) => new Promise((resolve, reject) => {
  db.get(
    'SELECT * FROM user_trips WHERE user_id=? AND trip_id=?',
    [userId, tripId],
    (err, booking) => {
      if (err) reject(err);
      else resolve(!!booking); // Returns true if booking exists, false otherwise
    }
  );
});

 const addTrip = (tripData) => new Promise((resolve, reject) => {
  const { title, destination, image, description, startDateTime, rating, price, length } = tripData;
  const code = uuidv4();
  db.run(
    `INSERT INTO trips (code, title, destination, image, description, startDateTime, rating, price, length)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [code, title, destination, image, description, startDateTime, rating, price, length],
    function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, code });
    }
  );
});

 const updateTrip = (tripData) => new Promise((resolve, reject) => {
  const { id, title, destination, image, description, startDateTime, rating, price, length } = tripData;
  db.run(
    `UPDATE trips
     SET title=?, destination=?, image=?, description=?, startDateTime=?, rating=?, price=?, length=?
     WHERE id=?`,
    [title, destination, image, description, startDateTime, rating, price, length, id],
    function (err) {
      if (err) reject(err);
      else resolve({ changes: this.changes });
    }
  );
});

 const deleteTrip = (id) => new Promise((resolve, reject) => {
  db.run('DELETE FROM trips WHERE id=?', [id], function (err) {
    if (err) reject(err);
    else resolve({ changes: this.changes });
  });
});

 const bookTrip = (userId, tripId) => new Promise((resolve, reject) => {
  db.run(
    'INSERT INTO user_trips (user_id, trip_id) VALUES (?, ?)',
    [userId, tripId],
    function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID });
    }
  );
});

 const unbookTrip = (userId, tripId) => new Promise((resolve, reject) => {
  db.run(
    'DELETE FROM user_trips WHERE user_id=? AND trip_id=?',
    [userId, tripId],
    function (err) {
      if (err) reject(err);
      else resolve({ changes: this.changes });
    }
  );
});

const getUserTrips = (userId) => new Promise((resolve, reject) => {
  db.all(
    `SELECT t.* FROM trips t
     JOIN user_trips ut ON t.id = ut.trip_id
     WHERE ut.user_id = ?`,
    [userId],
    (err, trips) => {
      if (err) reject(err);
      else resolve(trips);
    }
  );
});

module.exports = {
  init,
  addUser,
  updateUser,
  getUser,
  getUserByUsername,
  getAllUsers,
  getAllTrips,
  getTripByCode,
  addTrip,
  updateTrip,
  deleteTrip,
  bookTrip,
  unbookTrip,
  getUserTrips,
  isTrippedBooked
};