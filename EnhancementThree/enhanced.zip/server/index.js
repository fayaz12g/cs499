const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');

require('dotenv').config()

const app = express();
const router = express.Router();
const database = require('./database.js');

const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use('/api', router);

// Initialize Database
database.init();

// JWT Token Verification Middleware
const verifyToken = (req, res, next) => {
  // Get token from "Bearer <token>"
  const token = req.header('Authorization')?.split(' ')[1];

  if (!token) {
    return res.status(403).json({ message: 'No token provided' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }
    req.user = decoded;
    next();
  });
};

// ROUTES //

// Add new user
router.route('/users').post(async (req, res) => {
  const loginUser = req.body;
  try {
    let dbUser;
    if (loginUser.username) {
      dbUser = await database.getUserByUsername(loginUser.username);
    }
    if (dbUser) {
      res.status(400).json({ error: "User already exists" });
      return
    }
    // Add user to database
    const userAdded = await database.addUser(req.body);
    res.json(userAdded);
  } catch (error) {
    console.error('Error adding user:', error);
    res.status(400).json({ error: error });
  }
});

// Login user
router.route('/login').post(async (req, res) => {
  const loginUser = req.body;
  try {
    let dbUser;
    if (loginUser.username) {
      dbUser = await database.getUserByUsername(loginUser.username);
    }
    if (dbUser && loginUser.password && dbUser.password == loginUser.password) {
      const username = loginUser.username;
      const payload = { username };
      const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });
      res.json({ token });
    } else {
      res.status(401).json({ error: "Invalid login information" });
    }
  } catch (error) {
    console.error('Error logging in user:', error);
    res.status(500).json({ error: error });
  }
});

// Get all users
router.route('/users').get(verifyToken, async (req, res) => {
  try {
    const users = await database.getAllUsers();
    res.json(users)
  } catch (error) {
    console.error('Error getting all users:', error);
    res.status(500).json({ error: error });
  }
});

// Get all trips
router.route('/trips').get(async (req, res) => {
  try {
    const trips = await database.getAllTrips();
    res.json(trips)
  } catch (error) {
    console.error('Error getting all trips:', error);
    res.status(500).json({ error: error });
  }
});

// Get trip by code
router.get('/trips/:code', async (req, res) => {
  try {
    const trip = await database.getTripByCode(req.params.code);
    if (!trip) return res.status(404).json({ error: 'Trip not found' });
    res.json(trip);
  } catch (error) {
    console.error('Error getting trip:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get currently logged in user
router.route('/users/current').get(verifyToken, async (req, res) => {
  try {
    const user = await database.getUserByUsername(req.user.username);
    res.json(user);
  } catch (error) {
    console.error('Error getting current user:', error);
    res.status(500).json({ error: error });
  }
});

// Edit currently logged in user information
router.route('/users/current').put(verifyToken, async (req, res) => {
  const userInput = req.body;
  try {
    const currentUser = await database.getUserByUsername(req.user.username);

    userInput.id = currentUser.id;
    const editedUser = await database.updateUser(userInput);
    res.json(editedUser);
  } catch (error) {
    console.error('Error editing user:', error);
    res.status(500).json({ error: error });
  }
});

// Update trip
router.route('/trips/:code').put(verifyToken, async (req, res) => {
  try {
    const currentUser = await database.getUserByUsername(req.user.username);
    const trip = await database.getTripByCode(req.params.code);

    if (!trip) {
      return res.status(404).json({ error: "Trip Not Found" });
    }

    if (!currentUser.admin) {
      return res.status(403).json({ error: "You are not authorized to update trips." });
    }

    const updates = req.body;
    await database.updateTrip({ id: trip.id, ...updates });

    res.json({ success: true, message: "Trip updated successfully" });
  } catch (error) {
    console.error('Error updating trip:', error);
    res.status(500).json({ error: error.message });
  }
});

// Check Admin Status
router.route('/users/admin').post(verifyToken, async (req, res) => {
  try {
    const currentUser = await database.getUserByUsername(req.user.username);
    if (!currentUser) return res.status(404).json({ error: 'User not found' });
    console.log('Admin status checked:', currentUser.admin);
    res.json({ admin: currentUser.admin });
  } catch (error) {
    console.error('Error checking admin status:', error);
    res.status(500).json({ error: error.message });
  }
});

// Delete trip
router.route('/trips/:code').delete(verifyToken, async (req, res) => {
  try {
    const currentUser = await database.getUserByUsername(req.user.username);
    const trip = await database.getTripByCode(req.params.code);

    if (!trip) {
      return res.status(404).json({ error: "Trip Not Found" });
    }

    if (!currentUser.admin) {
      return res.status(403).json({ error: "You are not authorized to delete trips." });
    }

    await database.deleteTrip(trip.id);
    console.log(`Trip deleted: ${trip.id}`);
    res.json({ success: true, message: "Trip deleted successfully" });
  } catch (error) {
    console.error('Error deleting trip:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get user's trips
router.route('/moderate/trips').get(verifyToken, async (req, res) => {
  try {
    const currentUser = await database.getUserByUsername(req.user.username);
    const trips = await database.getUserTrips(currentUser.id);

    res.json(trips);
  } catch (error) {
    console.error('Error getting user trips:', error);
    res.status(500).json({ error: error.message });
  }
});

// Post a new trip
router.post('/trips', verifyToken, async (req, res) => {
  try {
    const user = await database.getUserByUsername(req.user.username);
    const tripData = req.body;

    const trip = await database.addTrip({ ...tripData, userId: user.id });
    res.status(201).json(trip);
  } catch (error) {
    console.error('Error posting new trip:', error);
    res.status(500).json({ error: error.message });
  }
});

// Book a trip
router.post('/trips/:code/book', verifyToken, async (req, res) => {
  try {
    const user = await database.getUserByUsername(req.user.username);
    const trip = await database.getTripByCode(req.params.code);

    if (!trip) return res.status(404).json({ error: 'Trip not found' });

    // Check if already booked
    const alreadyBooked = await database.isTrippedBooked(user.id, trip.id);
    if (alreadyBooked) {
      return res.status(409).json({ error: 'Trip already booked' });
    }

    await database.bookTrip(user.id, trip.id);
    res.json({ success: true, message: 'Trip booked successfully!' });
  } catch (error) {
    console.error('Error booking trip:', error);
    res.status(500).json({ error: error.message });
  }
});

// Unbook a trip
router.delete('/trips/:code/book', verifyToken, async (req, res) => {
  try {
    const user = await database.getUserByUsername(req.user.username);
    const trip = await database.getTripByCode(req.params.code);

    if (!trip) return res.status(404).json({ error: 'Trip not found' });

    await database.unbookTrip(user.id, trip.id);
    res.json({ success: true, message: 'Trip unbooked successfully!' });
  } catch (error) {
    console.error('Error unbooking trip:', error);
    res.status(500).json({ error: error.message });
  }
});


// Serve the app
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
