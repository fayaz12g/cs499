var fs = require('fs');
var homeData = JSON.parse(fs.readFileSync('./data/homeData.json','utf8'));

/* GET Homepage */
const index = function(req, res){
    console.log('Inside app_server, controllers, main.js, index function');
    res.render('index', { title: 'Travlr Getaways', homeData });
}

module.exports = {
  index
};
