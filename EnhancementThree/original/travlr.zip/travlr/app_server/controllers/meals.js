var fs = require('fs');
var mealData = JSON.parse(fs.readFileSync('./data/mealData.json','utf8'));


/* GET meals view */
const meals = function(req, res){
    console.log('Inside app_server, controllers, meals.js, meals function');
    res.render('meals', { title: 'Travlr Getaways', mealData });
}

module.exports = {
  meals
};
