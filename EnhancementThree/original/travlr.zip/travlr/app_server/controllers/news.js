var fs = require('fs');
var newsData = JSON.parse(fs.readFileSync('./data/newsData.json','utf8'));


/* GET news view */
const news = function(req, res){
    console.log('Inside app_server, controllers, news.js, news function');
    res.render('news', { title: 'Travlr Getaways', newsData });
}

module.exports = {
  news
};
