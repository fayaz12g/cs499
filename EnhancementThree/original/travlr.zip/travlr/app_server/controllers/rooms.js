var fs = require('fs');
var roomData = JSON.parse(fs.readFileSync('./data/roomData.json','utf8'));


/* GET rooms view */
const rooms = function(req, res){
    console.log('Inside app_server, controllers, rooms.js, rooms function');
    res.render('rooms', { title: 'Travlr Getaways', roomData });
}

module.exports = {
  rooms
};
