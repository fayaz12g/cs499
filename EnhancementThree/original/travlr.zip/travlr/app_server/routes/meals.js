var express = require('express');
var router = express.Router();
const controller = require('../controllers/meals');

/* GET meals page. */
console.log('Inside app_server, routes, meals.js');
router.get('/', controller.meals);

module.exports = router;
