var express = require('express');
var router = express.Router();
const controller = require('../controllers/news');

/* GET news page. */
console.log('Inside app_server, routes, news.js');
router.get('/', controller.news);

module.exports = router;
