"use client";

import { useState } from "react";
import Papa from "papaparse"; // used to parse through CSV

export default function Page() {
  const [courses, setCourses] = useState({}); // courses map
  const [sorted, setSorted] = useState([]); // sorted course map to export

  // Function to parse through the uploaded CSV file
  const handleFileUpload = (event) => {
    const file = event.target.files[0]; // first selected file
    if (!file) return; // handle edge case of no file

    // call the parser
    Papa.parse(file, {
      complete: (results) => {
        const courses = results.data; // load the courses from results
        const courseMap = {}; // initialize temp course map

        courses.forEach((row) => {
          if (row.length < 2) return; // skip invalid lines, commas should exist even with no prereqs
          
          // first part is the course number
          const courseNumber = row[0].trim()
            .toUpperCase(); 
            
          // second part is the course name
          const courseName = row[1]
            .trim(); 

           // rest are prerequisites
          const prerequisites = row.slice(2).map((p) => p.trim()
            .toUpperCase()) // standardize case (like others)
            .filter(Boolean); // remove empty strings (for courses with no prereqs)

          // add to course map
          courseMap[courseNumber] = {
            courseNumber,
            courseName,
            prerequisites,
          };
        });

        // Update our global map
        setCourses(courseMap);

        // Build sorted course list
        const sortedList = Object.values(courseMap)
          .sort((a, b) => a.courseNumber
            .localeCompare(b.courseNumber)); // sort by the course number

        // Update our global map
        setSorted(sortedList);
      },
    });
  };

  // rendering of courses and their prerequisites
  const renderCourses = (course) => {
    return (
      <div key={course.courseNumber} className="ml-4 border-l pl-2">
        <p className="font-medium">
      {/* // start by displaying the course number and name */}
          {course.courseNumber} – {course.courseName} 
        </p>
        {/* only render the tree if there are prerequisites */}
        {course.prerequisites.length > 0 && (
          <div className="ml-4">
            <p className="italic">Prerequisites:</p>
            {course.prerequisites.map((p) => {
              const prereq = courses[p];
              if (prereq) {
                // recursively render prerequisites
                return renderCourses(prereq);
              } else {
                // handle edge case of a prerequisite not found in the map
                return (
                  <p key={p} className="ml-4 text-red-500">
                    {p} (not found)
                  </p>
                );
              }
            })}
          </div>
        )}
      </div>
    );
  };

  // Export sorted CSV
  const handleExport = () => {
    if (sorted.length === 0) return; // handle edge case of no courses in sorted map
    
    const csvRows = [["Course Number", "Course Name", "Prerequisites"]]; // define header row
    // iterate through courses in the sorted list, adding them to the CSV rows
    sorted.forEach((course) => {
      csvRows.push([course.courseNumber, course.courseName, ...course.prerequisites]);
    });

    // convert to CSV string
    const csvString = Papa.unparse(csvRows);

    // Create a file to send to the user and trigger download
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sorted_courses.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    // Tailwind CSS for styling
    <div className="min-h-screen p-6">
      <div className="max-w-3xl mx-auto bg-white/40 dark:bg-black/40 backdrop-blur-md shadow-lg rounded-2xl p-6">
        {/* Header */}
        <h1 className="text-2xl font-bold mb-4">Course Planner</h1>

        {/* File input */}
        <div className="mb-4">
          <label className="block mb-2 font-medium">Upload CSV of Courses</label>
          <input
            type="file" // define input type to create "Choose File" button
            accept=".csv" // only accept CSV files
            onChange={handleFileUpload}
            // Tailwind styling for the button and text display
            className="block w-full text-sm text-red-600 file:mr-4 file:py-2 file:px-4
                       file:rounded-full file:border-0 file:text-sm file:font-semibold
                       file:bg-blue-50 file:text-gray-700 hover:file:bg-blue-100"
          />
        </div>

        {/* Export Button */}
        {sorted.length > 0 && ( // only show if there are courses to export
          <button
            onClick={handleExport} // call export function on click
            className="mb-6 px-4 py-2 bg-green-600 text-white rounded-xl shadow hover:bg-green-700"
          >
            Export Sorted CSV
          </button>
        )}

        {/* Course Tree */}
        {sorted.length > 0 ? (
          <div className="space-y-4">
            {sorted.map((course) => renderCourses(course))} {/* render each course using the renderCourses function */}
          </div>
        ) : (
          // Alternate text if no courses loaded
          <p className="text-gray-500">No courses loaded yet.</p>
        )}
      </div>
    </div>
  );
}
