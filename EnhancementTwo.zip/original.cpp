// ProjectTwo.cpp
// Fayaz Shaikh
// 10/20/2024
// CS300 DSA SNHU

#include <iostream> // input and output
#include <fstream> // File stream
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>  // for the to upper in the search function

using namespace std;

// Define the Course structure
struct Course {
    string courseNumber;
    string courseName;
    vector<string> prerequisites;
};

// Function prototypes
void displayMenu();
void importFile(unordered_map<string, Course>& courses);
void printSortedCourseList(const unordered_map<string, Course>& courses);
void printCourseInfo(const unordered_map<string, Course>& courses);

// Main function
int main() {
    unordered_map<string, Course> courses;
    int choice;

    cout << "Welcome to the course planner.\n";

    // Main program loop
    while (true) {
        displayMenu(); // Display the menu

        if (cin >> choice) { // New error checking, only if the choice was an int and successfuly set to the variable
            switch (choice) { // Change case based on input
            case 1:
                importFile(courses); // Import the file for menu option 1
                break;
            case 2:
                printSortedCourseList(courses); // Print out all courses for option 2
                break;
            case 3:
                printCourseInfo(courses); // Print a specific course for option 3
                break;
            case 9:
                cout << "Thank you for using the course planner!\n"; // Output a goodbye message and exit loop for option 9
                return 0;
            default:
                cout << choice << " is not a valid option.\n"; // Error handling for an unknown entry
            }
        }
        else { // Otherwise, handle the non int
            cin.clear(); // Clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
            cout << "Invalid input. Please enter a number.\n";
        }
    }
    return 0; // Return 0 in case while loop ever exits (which it should not)
}

// Function to display the menu
void displayMenu() {
    cout << "\n1. Load Data Structure.\n";
    cout << "2. Print Course List.\n";
    cout << "3. Print Course.\n";
    cout << "9. Exit\n";
    cout << "What would you like to do? "; // Trailing space to leave room between user input
}

// Function to import file and load data structure
void importFile(unordered_map<string, Course>& courses) {
    string filename; // initalize filename string
    cout << "Enter the file name: "; 
    cin >> filename; // Get the filename from the user

    ifstream file(filename); // Define the file input stream with the filename

    // If the file could not be found, display a verbose error message with intructions
    if (!file) {
        cout << "Error: Unable to open file. Ensure it is located in the same directory as the cpp file and you typed the full name including the .csv extension.\n";
        return; // Go back to the main while loop
    }

    // Assuming the file was found (we did not return), continue on
    courses.clear(); // Clear existing data

    string line; // Initialize a string for each line
    while (getline(file, line)) { // While there are more lines in the file
        istringstream iss(line);
        string courseNumber, courseName, prereq; // Initialize the strings for the 3 values we store
        vector<string> prerequisites; // Initialize the vector for the prerequisites

        if (getline(iss, courseNumber, ',') && // Find the course number seperated by a comma
            getline(iss, courseName, ',')) { // Find the course name seperated by a comma

            Course course; // Define the course object
            course.courseNumber = courseNumber; // Set the number
            course.courseName = courseName; // Set the name

            while (getline(iss, prereq, ',')) { // Anything else is a pre-req
                if (!prereq.empty()) { // Handle no pre-reqs case
                    prerequisites.push_back(prereq);
                }
            }
            course.prerequisites = prerequisites; // Set the pre-reqs vector

            courses[courseNumber] = course; // Set the course object into the object
        }
        // Print an error if course number and name not found by comma seperated entries (less than 2 things), then loop
        else {
            cout << "Error: Invalid format in line: " << line << "\n";
        }
    }

    // Print that the file is done after the last line
    cout << "File loaded successfully.\n";
}

// Function to print sorted course list in alphanumeric order
void printSortedCourseList(const unordered_map<string, Course>& courses) {
    // Handle edge case where courses were not loaded first
    if (courses.empty()) {
        cout << "No courses loaded. Please load data first.\n";
        return; // Return to main loop
    }

    // Get sorted courses
    vector<pair<string, string>> sortedCourses;
    for (const auto& course : courses) {
        sortedCourses.push_back({ course.second.courseNumber, course.second.courseName });
    }

    // Sort the courses
    sort(sortedCourses.begin(), sortedCourses.end());

    // Display the courses with intro message
    cout << "Here is a sample schedule:\n\n";
    for (const auto& course : sortedCourses) {
        cout << course.first << ", " << course.second << "\n";
    }
}


// Function to convert a full string to uppercase
string toUpper(const string& str) {
    string upper;
    for (char c : str) { // For every character (not numbers, such as "csci" in "csci400" to become "CSCI400")
        upper += toupper(c);
    }
    return upper;
}

// Function to print course information
void printCourseInfo(const unordered_map<string, Course>& courses) {
    string courseNumber; // initialize local course number input
    cout << "What course do you want to know about? "; // trailing space to get input
    cin >> courseNumber;

    // Convert input to uppercase so that lowercase inputs can be read
    courseNumber = toUpper(courseNumber);

    auto it = courses.find(courseNumber);
    if (it != courses.end()) { // If it was found (did not reach the end)
        const Course& course = it->second; // get the course object
        cout << course.courseNumber << ", " << course.courseName << "\n"; // Print hte name and number

        // Handle edge case with no pre-requisites
        if (course.prerequisites.empty()) {
            cout << "Prerequisites: None\n";
        }

        // Otherwise, print the pre-requisites
        else {
            cout << "Prerequisites: ";
            for (size_t i = 0; i < course.prerequisites.size(); ++i) { // For every pre-requisite in the list
                const auto& prereq = course.prerequisites[i];
                auto prereqIt = courses.find(prereq);
                if (prereqIt != courses.end()) {
                    cout << prereq; // Output the pre-requisite

                    // If it is not the end, put a comma for the next pre-req
                    if (i < course.prerequisites.size() - 1) {
                        cout << ", ";
                    }
                }
                // Handle if pre-req is not found (despite error checking on loading)
                else {
                    cout << prereq << " (not found)";
                }
            }
            cout << "\n";
        }
    }

    // Handle if the course is not found (repeating the input)
    else {
        cout << courseNumber << " not found.\n";
    }
}